import AgentSignup from "@/app/components/signup/AgentSignup";

export default function Page() {
  return <AgentSignup />;
}

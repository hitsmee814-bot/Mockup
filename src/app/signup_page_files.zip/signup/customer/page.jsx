import CustomerSignup from "@/app/components/signup/CustomerSignup";

export default function CustomerSignupPage() {
  return <CustomerSignup />;
}
